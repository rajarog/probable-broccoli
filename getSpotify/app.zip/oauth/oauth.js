const axios = require('axios');
const oauth = require('axios-oauth-client');

const getClientCredentials = oauth.client(axios.create(), {
  url: 'https://accounts.spotify.com/api/token',
  grant_type: 'client_credentials',
  client_id: '97d0706c44be4c609b732d0f61c0553f',
  client_secret: '26d533d5bd1e4438a3e40896e7c2de26',
  scope: 'playlist-read-private'
});

module.exports = { getClientCredentials };
