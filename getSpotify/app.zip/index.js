const oauth = require('./oauth/oauth');

exports.handler = async event => {
  const token = await oauth
    .getClientCredentials()
    .then(data => data.access_token);

  const response = {
    statusCode: 200,
    body: JSON.stringify(token)
  };
  return response;
};
